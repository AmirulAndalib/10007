#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

#自定义添加/删除host

function add_value() {
local file="${1}"
local local_host_file="${2}"
local name="$(echo ${file##*/}| sed "s|\..*||g")"
local add_value="$(cat "${file}" | sed "s/^[[:space:]]//g;/^\#.*/d;/^[[:space:]]*$/d")"
if test -f "${file}" ;then
cat <<key>>$local_host_file
#${name}
$add_value
#END
key
fi
}

function wipe_value() {
local file="${1}"
local local_host_file="${2}"
if test -f "$file" ; then
for i in $(cat "${file}" | sed "s|^.*[0-9].*\..*[0-9].*\..*[0-9].*\..*[0-9].*[[:space:]]||g;s|^.*[0-9].*\..*[0-9].*\..*[0-9].*\..*[0-9].*	||g;s/^[[:space:]]//g;/^#.*/d;/^[[:space:]]*$/d" )
	do
	sed -i "/$i/d" $local_host_file && echo "已删除[ $i ]"
done
fi
}

function mod_host_file() {
local file="${2}"
local value="${1}"
#local dir="${0%/*}"
local dir="$MODPATH"
find "${dir}" -iname "hosts" -type f | while read target_host ;do
	if test "${value}" = "添加" ;then
	cp -rf "${target_host}" "${target_host%/*}/hosts.bak"
		add_value "$file" "${target_host}"
	elif test "${value}" = "删除" ;then
	cp -rf "${target_host}" "${target_host%/*}/hosts.bak"
		wipe_value "$file" "${target_host}"
	fi
done
}

#添加host
#mod_host_file "添加" "文件路径"
#"${0%/*}"代表当前目录，"${0%/*}/腾讯.conf"表示当前目录下有个"腾讯.conf"的文件。
#例如
mod_host_file "添加" "${0%/*}/腾讯.conf"

#删除host
#mod_host_file "删除" "文件路径"
#"${0%/*}"代表当前目录，"${0%/*}/腾讯.conf"表示当前目录下有个"腾讯.conf"的文件。
#例如
#mod_host_file "删除" "${0%/*}/腾讯.conf"

