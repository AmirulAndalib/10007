id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

function method_kill_apps(){
local packagename="$i"
if test $(show_value "chattr锁定") == 是 ;then
	find /data/user/*/$packagename /data/data/$packagename /data/media/*/Android/data/$packagename -iname "app_tbs*" -type d -o -iname "res_cache" -type d -o -iname "app_mod_resource" -type d -o -iname "neuron_report*.db" -type f 2>/dev/null | while read path ;do
		X_file "${path}"
	done
else 
	find /data/user/*/$packagename /data/data/$packagename /data/media/*/Android/data/$packagename -iname "app_tbs*" -type d -o -iname "res_cache" -type d -o -iname "app_mod_resource" -type d -o -iname "neuron_report*.db" -type f 2>/dev/null | while read path ;do
		mkdir_file "${path}"
	done
fi
}

function fixed_owner(){
local package_name="${1}"
test "${package_name}" != ""
local uid="$(cmd package list package -U "${package_name}" | grep "package:${package_name}[[:space:]]uid:" | sed 's/.*uid://g' | tr -cd [0-9])"
if test "${uid}" != "" -a -d "/data/media/0/Android/data/${package_name}/download" ;then
chmod -R 0777 "/data/media/0/Android/data/${package_name}/download"
chown -R "${uid}:${uid}" "/data/media/0/Android/data/${package_name}/download"
fi
}



local apps="
com.bilibili.app.in
com.bilibili.app.blue
tv.danmaku.bili
tv.danmaku.bilj
tv.danmaku.bilibilihd
com.bilibili.bilithings
"
for i in $apps 
do
	fixed_owner "${i}"
	method_kill_apps "$i"
done

