id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh


#运行，锁定字节跳动下的穿山甲广告/收集隐私的文件
if test $(show_value "chattr锁定") == 是 ;then
	find /data/user /data/data /data/media/*/Android/data -iname "xm_ad_img_cache" -type d -o -iname "ads" -type d -o -iname "douban_ad" -type d -o -iname "splashCache" -type d -o -iname "SplashPreload" -type d -o -iname "splash_image" -type d -o -iname "splashCache" -type d -o -iname "SplashData" -type d -o -iname "TMEAds" -type d -o -iname "qad_cache" -type d -o -iname "SplashPreload" -type d -o -iname "splash_ad_cache" -type d -o -iname "GDTDOWNLOAD" -type d -o -iname "app_adnet" -type d  -o -iname "tad_cache" -type d  -o -iname "app_ad" -type d -o -iname "TTCache" -type d  -o -iname "app_ad" -type d  -o -iname "cachett_ad" -type d  -o -iname "tt_tmpl_pkg" -type d  -o -iname "com_qq_e_download"  -type d  -o -iname "pangle_com.byted.pangle" -type d -o -iname "ksadsdk" -type d 2>/dev/null | while read adfile ;do
		X_file "${adfile}" 2>/dev/null
	done
else 
	find /data/user /data/data /data/media/*/Android/data -iname "xm_ad_img_cache" -type d -o -iname "ads" -type d -o -iname "douban_ad" -type d -o -iname "splashCache" -type d -o -iname "SplashPreload" -type d -o -iname "splash_image" -type d -o -iname "splashCache" -type d -o -iname "SplashData" -type d -o -iname "TMEAds" -type d -o -iname "qad_cache" -type d -o -iname "SplashPreload" -type d -o -iname "splash_ad_cache" -type d -o -iname "GDTDOWNLOAD" -type d -o -iname "app_adnet" -type d  -o -iname "tad_cache" -type d  -o -iname "app_ad" -type d -o -iname "TTCache" -type d  -o -iname "app_ad" -type d  -o -iname "cachett_ad" -type d  -o -iname "tt_tmpl_pkg" -type d  -o -iname "com_qq_e_download"  -type d  -o -iname "pangle_com.byted.pangle" -type d -o -iname "ksadsdk" -type d 2>/dev/null | while read adfile ;do
		mkdir_file "${adfile}" 2>/dev/null
	done
fi