#小米云备份禁用
iptables -A OUTPUT -m string --string "a0.app.xiaomi.com" --algo bm --to 65535 -j DROP
#去掉注释则云备份启用
#iptables -D OUTPUT -m string --string "a0.app.xiaomi.com" --algo bm --to 65535 -j DROP

